package com.sxs.item.service.getui;

import com.igexin.sdk.PushService;

/**
 * @Author: a797s
 * @Date: 2019/12/16 10:02
 * @Desc:
 */
public class GeTuiPushService extends PushService {
}

