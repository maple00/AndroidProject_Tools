package com.sxs.item.ui.fragment;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.sxs.item.R;
import com.sxs.item.common.BaseFragment;

/**
 * @Author: shearson
 * @time: 2019/11/27 11:32
 * @des: Fragment C
 */
public class FragmentC extends BaseFragment implements View.OnClickListener {

    private ImageView mImageView;

    @Override
    protected int initLayout() {
        return R.layout.fragment_mes;
    }

    //  初始化控件
    @Override
    protected void initView(final View view) {

        mImageView = view.findViewById(R.id.iv_show_image);
        // 正常显示图片
        view.findViewById(R.id.btn_normal_image).setOnClickListener(this);
        // 加载圆形图片
        view.findViewById(R.id.btn_round_image).setOnClickListener(this);
        // 加载圆角图片
        view.findViewById(R.id.btn_corner_image).setOnClickListener(this);
        // 选择一张图片
        view.findViewById(R.id.btn_choose_img).setOnClickListener(this);
        // 请求一次权限
        view.findViewById(R.id.btn_request_permission).setOnClickListener(this);
    }

    // 初始化数据
    @Override
    protected void initData(Context mContext) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_normal_image:
                mImageView.setVisibility(View.VISIBLE);
                Glide.with(view).load("https://www.baidu.com/img/bd_logo.png").into(mImageView);
                break;
            case R.id.btn_round_image:
                mImageView.setVisibility(View.VISIBLE);
                Glide.with(view)
                        .load("https://www.baidu.com/img/bd_logo.png")
                        .apply(RequestOptions.bitmapTransform(new CircleCrop()).circleCrop())
                        .into(mImageView);
                break;
            case R.id.btn_corner_image:
                mImageView.setVisibility(View.VISIBLE);
                //设置图片圆角角度
//                RoundedCorners roundedCorners = new RoundedCorners(100);
//                //通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
//                // RequestOptions options = RequestOptions.bitmapTransform(roundedCorners).override(300, 300);
//                RequestOptions options = RequestOptions.bitmapTransform(roundedCorners);

                Glide.with(view).load("https://www.baidu.com/img/bd_logo.png")
                        .apply(RequestOptions.bitmapTransform(new RoundedCorners(20)).override(300, 300))
                        .into(mImageView);
                break;
            case R.id.btn_choose_img:
                toast("暂没实现");
                break;
            case R.id.btn_request_permission:
                PermissionUtils
                break;

        }
    }
}
