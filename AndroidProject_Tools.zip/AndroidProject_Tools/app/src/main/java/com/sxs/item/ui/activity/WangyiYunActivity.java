package com.sxs.item.ui.activity;

import android.view.View;

import com.sxs.item.R;
import com.sxs.item.base.BaseActivity;

/**
 * @Author: a797s
 * @Date: 2019/12/16 10:50
 * @Desc: 网易云集成Demo
 */
public class WangyiYunActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected int getLayoutId() {
        return R.layout.activity_wangyi;
    }



    @Override
    protected void initView() {

    }

    @Override
    public void onClick(View v) {

    }
}
