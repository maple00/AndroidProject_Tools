package com.sxs.item.common;

/**
 * @Author: a797s
 * @Date: 2019/12/13 17:11
 * @Desc: 常量说明
 */
public final class Contants {


}
