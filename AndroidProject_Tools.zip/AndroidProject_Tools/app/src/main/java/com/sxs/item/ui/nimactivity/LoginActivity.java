package com.sxs.item.ui.nimactivity;

import android.view.View;

import com.sxs.item.R;
import com.sxs.item.base.BaseActivity;

/**
 * @Author: a797s
 * @Date: 2019/12/18 11:01
 * @Desc: 登录
 */
public class LoginActivity extends BaseActivity implements View.OnClickListener {

    @Override
    protected int getLayoutId() {
        return R.layout.acitivity_nim_login;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    protected void initView() {

    }
}
